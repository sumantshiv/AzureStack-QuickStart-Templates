#http://geekswithblogs.net/Wchrabaszcz/archive/2013/09/04/how-to-install-windows-server-features-using-powershell--server.aspx
Configuration WebServerConfig
{
	Node ("localhost")
	{
        #Reboot if needed.        LocalConfigurationManager        {            RebootNodeIfNeeded = $true        }

		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

        #Install the HTTP Redirection
		WindowsFeature HTTPRedirection
		{
			Ensure = "Present"
			Name = "Web-Http-Redirect"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install ASP.NET 3.5
		WindowsFeature ASP35
		{
			Ensure = "Present"
			Name = "Web-Asp-Net"
		}

		#Install NET Extensibility 35
		WindowsFeature NetExt35
		{
			Ensure = "Present"
			Name = "Web-Net-Ext"
		}
		
		#Install NET Extensibility 45
		WindowsFeature NetExt45
		{
			Ensure = "Present"
			Name = "Web-Net-Ext45"
		}

		#Install ISAPI Filters
		WindowsFeature ISAPI_Filters
		{
			Ensure = "Present"
			Name = "Web-ISAPI-Filter"
		}

		#Install ISAPI Extensions
		WindowsFeature WebISAPI_EXT
		{
			Ensure = "Present"
			Name = "Web-ISAPI-Ext"
		}

		#Install Default Document
		WindowsFeature DefaultDocument
		{
			Ensure = "Present"
			Name = "Web-Default-Doc"
		}

		#Install Static Content
		WindowsFeature StaticContent
		{
			Ensure = "Present"
			Name = "Web-Static-Content"
		}

		#Install Dynamic Content Compression
		WindowsFeature DynamicContentCompression
		{
			Ensure = "Present"
			Name = "Web-Dyn-Compression"
		}
		
		#Install Static Content Compression
		WindowsFeature StaticContentCompression
		{
			Ensure = "Present"
			Name = "Web-Stat-Compression"
		}

		#Install Request Filtering
		WindowsFeature RequestFiltering
		{
			Ensure = "Present"
			Name = "Web-Filtering"
		}

		WindowsFeature WebServerManagementConsole
		{
			Name = "Web-Mgmt-Console"
			Ensure = "Present"
		}

        Script Install_Net_4.5.2        {             SetScript = {                            $SourceURI = "https://download.microsoft.com/download/B/4/1/B4119C11-0423-477B-80EE-7A474314B347/NDP452-KB2901954-Web.exe"                            $FileName = $SourceURI.Split('/')[-1]                            $BinPath = Join-Path $env:SystemRoot -ChildPath "Temp\$FileName"

                            if (!(Test-Path $BinPath))                            {                                Invoke-Webrequest -Uri $SourceURI -OutFile $BinPath                            }

                            write-verbose "Installing .Net 4.5.2 from $BinPath"                            write-verbose "Executing $binpath /q /norestart"                            Sleep 5                            Start-Process -FilePath $BinPath -ArgumentList "/q /norestart" -Wait -NoNewWindow                                        Sleep 5                            Write-Verbose "Setting DSCMachineStatus to reboot server after DSC run is completed"                            $global:DSCMachineStatus = 1            }

            TestScript = {                            [int]$NetBuildVersion = 379893

                            if (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' | %{$_ -match 'Release'})                            {                                [int]$CurrentRelease = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full').Release                                if ($CurrentRelease -lt $NetBuildVersion)                                {                                    Write-Verbose "Current .Net build version is less than 4.5.2 ($CurrentRelease)"                                    return $false                                }                                else                                {                                    Write-Verbose "Current .Net build version is the same as or higher than 4.5.2 ($CurrentRelease)"                                    return $true                                }                            }                            else                            {                                Write-Verbose ".Net build version not recognised"                                return $false                            }            }

            GetScript = {                if (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' | %{$_ -match 'Release'})                {                    $NetBuildVersion =  (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full').Release                    return $NetBuildVersion                }                else                {                    Write-Verbose ".Net build version not recognised"                    return ".Net 4.5.2 not found"                }            }
        }
	}
} 